let er_num = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;
let str = "123-456-7890";
console.log(er_num.test(str));